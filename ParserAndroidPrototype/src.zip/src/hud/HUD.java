package hud;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import game.Entity;
import game.GameState;
import game.test.R;
import gameEngine.Sprite;

public class HUD
{
	private Button redCell;
	private Button whiteCell;
	private Button platelet;
	private HighLight highLighter;
	private GameState gameStateRef;
	private int SPACER;
	private int BUTTONY;
	private int BUTTON_RAD;
	private int SCR_WIDTH;
	private int SCR_HEIGHT;
	
	public HUD(GameState stateRef)
	{
		gameStateRef = stateRef;
		setPositions();
		CreateButtons();
	}
	
	public void draw(Canvas dbimage)
	{
		redCell.draw(dbimage);
		whiteCell.draw(dbimage);
		platelet.draw(dbimage);
		highLighter.draw(dbimage);
	}
	
	public void interact(int clickX, int clickY)
	{
		if(redCell.clicked(clickX, clickY))
			{
				gameStateRef.switchCellType(Entity.REDCELL);
				highLighter.setPosX((int) (SCR_WIDTH * 0.5)	);
			}
		if(whiteCell.clicked(clickX, clickY))
			{
				gameStateRef.switchCellType(Entity.WHITECELL);
				highLighter.setPosX((int) (SCR_WIDTH * 0.5)	- SPACER);
			}
		if(platelet.clicked(clickX, clickY))
			{
				gameStateRef.switchCellType(Entity.PLATELET);
				highLighter.setPosX((int) (SCR_WIDTH * 0.5)	+ SPACER);
			}
	}
	
	private void setPositions()
	{
		//set pos for button elements depending on the screen size.
		//Maybe we want to do a check for the large/medium./small screen?
		SCR_WIDTH = gameStateRef.getWindowWidth();
		SCR_HEIGHT = gameStateRef.getWindowHeight();
		SPACER = (int) (SCR_WIDTH * 0.25);
		BUTTONY = (int) ( SCR_HEIGHT - (SCR_HEIGHT * 0.2));
		BUTTON_RAD = (int) (SCR_WIDTH * 0.16);
	}
	
	private void CreateButtons()
	{
		redCell = new Button( (int) (SCR_WIDTH * 0.5), BUTTONY, BUTTON_RAD, BUTTON_RAD);
		Bitmap bitmapSprite = BitmapFactory.decodeResource(gameStateRef.getGameView().getResources(), R.drawable.red_cells);
		Sprite sprite = new Sprite(bitmapSprite, 1, 1, 1, 1);
		sprite.setAlpha(220);
		redCell.setSprite(sprite);
		
		whiteCell = new Button((int) (SCR_WIDTH * 0.5) - SPACER, BUTTONY, BUTTON_RAD, BUTTON_RAD);
		bitmapSprite = BitmapFactory.decodeResource(gameStateRef.getGameView().getResources(), R.drawable.white_cells);
		sprite = new Sprite(bitmapSprite, 1, 1, 1, 1);
		sprite.setAlpha(150);
		whiteCell.setSprite(sprite);
		
		platelet = new Button((int) (SCR_WIDTH * 0.5) + SPACER, BUTTONY, BUTTON_RAD, BUTTON_RAD);
		bitmapSprite = BitmapFactory.decodeResource(gameStateRef.getGameView().getResources(), R.drawable.platelets);
		sprite = new Sprite(bitmapSprite, 1, 1, 1, 1);
		sprite.setAlpha(150);
		platelet.setSprite(sprite);
		
		highLighter = new HighLight( (int) (SCR_WIDTH * 0.5) - SPACER, BUTTONY, (int) (BUTTON_RAD * 1.06), (int) (BUTTON_RAD * 1.06) );
		highLighter.setPaint();
	}
}