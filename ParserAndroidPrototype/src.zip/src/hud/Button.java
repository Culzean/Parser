package hud;

import game.test.R;
import gameEngine.Sprite;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

public class Button 
{
	private int positionX, positionY;
	private int width, height;
	protected Paint color;
	protected Sprite sprite;
	
	public Button(int posX, int posY, int _width, int _height)
	{
		setPosX(posX);
		setPosY(posY);
		width = _width;
		height = _height;
		color = new Paint();
		color.setColor(Color.CYAN);
		color.setAlpha(255);
	}
	
	public void draw(Canvas dbimage)
	{
		if(sprite != null)
			sprite.draw(dbimage);
		else
			dbimage.drawRect(getPosX()-width/2, getPosY()-height/2, getPosX()+width/2, getPosY()+height/2, color);
	}
	
	public void setSprite(Sprite newSprite)
	{
		sprite = newSprite;
		sprite.resize(width, height);
		sprite.setLocation(getPosX()-sprite.getWidth()/2, getPosY()-sprite.getHeight()/2);
	}
	
	public boolean clicked(int clickX, int clickY)
	{
		//First see if these test are true ( means there is no collision)
		if(clickX > getPosX() + width/2) return false; // click too much on the right
		else if(clickX < getPosX() - width/2) return false; // click too much on the left
		else if(clickY < getPosY() - height/2) return false; // click over the button
		else if(clickY > getPosY() + height/2) return false; // click under the button
		//Else there is a collision
		else return true;
	}

	public int getPosX() {
		return positionX;
	}

	public void setPosX(int positionX) {
		this.positionX = positionX;
	}

	public int getPosY() {
		return positionY;
	}

	public void setPosY(int positionY) {
		this.positionY = positionY;
	}
}
