package hud;

import android.graphics.Color;
import android.graphics.Paint;

public class HighLight extends Button{

	public HighLight(int posX, int posY, int _width, int _height) {
		super(posX, posY, _width, _height);
	}
	
	public void setPaint()
	{
		this.color = new Paint();//the garbage collection should get the paint created in super
		color.setARGB(45, 44, 220, 165);
	}
	
	public boolean clicked(int clickX, int clickY)
	{
		return false;
	}

	
}
