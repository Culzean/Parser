package game.EntityMouvementBehavior;

import game.Entity;

public class FatCellStop  extends EntityMouvementBehavior{

	@Override
	public void update(Entity e1, double heartBeat) {
		// TODO Auto-generated method stub
		
	}

}
