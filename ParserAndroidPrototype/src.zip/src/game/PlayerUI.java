package game;

import events.Vector2D;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.hardware.SensorEvent;

import java.lang.Math;

public class PlayerUI 
{
	
	public final int MEASURE = 20;
	public final float MAX_RADIUS = 300.0f;
	
	private float[] xVals = new float[MEASURE];
	private float[] yVals = new float[MEASURE];
	private float[] zVals = new float[MEASURE];
	
	private int counter = 0;
	
	private float[] readVar = new float[3];
	
	private Vector2D playerInput = null;
	
	private int heartX;
	private int heartY;
	private Paint lineColour = new Paint();
	
	private GameModel gameModel = null;
	
	//class will determine which UI system is in use.
	//on update it will read the correct input and deliver a vector to assign directions to new cells
	//Will also read player input for choice of cell
	//
	//This class will provide a new vector that can be assigned to each cell
	//there are several ways to arrive at this value
	//here I will implement angular acceleration from the y axis
	//and scale from the x axis
	//
	//could also be calculated by two x and y scalars. which is simpler
	
	public PlayerUI(GameModel _model, int hX, int hY)
	{
		gameModel = _model;
		heartX = hX;	heartY = hY;
		playerInput = new Vector2D(0,0);
		lineColour.setColor(Color.argb(180, 50, 50, 50));
		lineColour.setStrokeWidth(4);
	}
	
	public Vector2D update( long dt)
	{
		float y = (float) ((gameModel.getCalibrateX() - getAverageRead(xVals)) * 0.1);
		float x = (float) ((gameModel.getCalibrateY() - getAverageRead(yVals)) * 0.1);
		
		playerInput.x = MAX_RADIUS* -x;
		playerInput.y = MAX_RADIUS* -y;
		
		return playerInput;
	}
	
	public void setValues(SensorEvent event)
	{
		//record a series of values from the accelerometer
		//Then take the average
		//there is a balance here between smooth values, delay to respond and performance
		xVals[counter] = event.values[0];
		yVals[counter] = event.values[1];
		zVals[counter] = event.values[2];
		if(++counter >= MEASURE)
			counter = 0;
	}
	
	public float getAverageRead(final float[] values)
	{
		float av = 0;
		float max = 0; float min = 0;
		for(int i =0; i<MEASURE; i++)
			{
				av += values[i];
				if(values[i] > max)
					max = values[i];
				else if(values[i] < min)
					min= values[i];
			}
		readVar[1]  = max - min;
		return av / MEASURE;
	}
	
	public void draw(Canvas g)
	{
		g.drawLine((int)heartX, (int)heartY, (int)playerInput.x + heartX, (int)(heartY + playerInput.y), lineColour);
	}
}
