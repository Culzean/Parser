package gameEngine;

import android.graphics.Canvas;
import android.view.SurfaceHolder;

public class ParserThread extends Thread 
{
    private ParserView parserView;
    private SurfaceHolder surfaceHolder;
    private boolean mRun = false;
    
    //Used to calculate the FPS
    private long startingTime;
    private long timeElapsed;
 
    public ParserThread(ParserView pView) 
    {
    	parserView = pView;
        surfaceHolder = parserView.getHolder();
    }
 
    public void setRunning(boolean run) { mRun = run; } 
    
    @Override
    public void run() 
    {
        Canvas canvas = null;
        //Starting time
        startingTime = System.currentTimeMillis();
        while (mRun) 
        {
	        canvas = surfaceHolder.lockCanvas();
	        if (canvas != null) 
	        {
	        	parserView.doDraw(timeElapsed, canvas);
	            timeElapsed = System.currentTimeMillis() - startingTime;
	            surfaceHolder.unlockCanvasAndPost(canvas);
	        }
	        startingTime = System.currentTimeMillis();
        }
    }
}
